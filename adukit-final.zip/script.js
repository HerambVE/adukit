/* ==========================================================================
   AduKit - Interactive Script
   1. Top Reading Progress Bar + Dual Scrollspy (Main Navbar & 6 Reagents Bar)
   2. Virtual Test Tube Reaction Simulator for the 6 Kit Reagents
   3. Category Filter + Home Detective Checklist for DART Everyday Tests
   4. Gentle Scroll Reveal Animations
   5. Re-renders button text when the language is switched (see i18n.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  /* ------------------------------------------------------------------------
     1. SCROLL PROGRESS BAR & DUAL SCROLLSPY
     ------------------------------------------------------------------------ */
  const progressBar = document.getElementById('scroll-progress-bar');
  const mainSections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  const reagentCards = document.querySelectorAll('.reagent-card[id]');
  const reagentPills = document.querySelectorAll('.reagent-pill');

  function handleScroll() {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    if (progressBar && docHeight > 0) {
      const pct = Math.min(100, Math.max(0, (scrollTop / docHeight) * 100));
      progressBar.style.width = `${pct}%`;
    }

    // Main Navbar Scrollspy
    const mainCheckPos = scrollTop + 170;
    mainSections.forEach((section) => {
      const top = section.offsetTop;
      const height = section.offsetHeight;
      const id = section.getAttribute('id');

      if (mainCheckPos >= top && mainCheckPos < top + height) {
        navLinks.forEach((link) => {
          link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
        });
      }
    });

    // 6 Reagents Sub-Navbar Scrollspy
    const reagentCheckPos = scrollTop + 260;
    let activeFound = false;

    reagentCards.forEach((card) => {
      const top = card.offsetTop;
      const height = card.offsetHeight;
      const id = card.getAttribute('id');

      if (reagentCheckPos >= top && reagentCheckPos < top + height) {
        activeFound = true;
        card.classList.add('in-view');
        reagentPills.forEach((pill) => {
          pill.classList.toggle('active', pill.getAttribute('href') === `#${id}`);
        });
      } else {
        card.classList.remove('in-view');
      }
    });

    if (!activeFound) {
      reagentPills.forEach((pill) => pill.classList.remove('active'));
    }
  }

  window.addEventListener('scroll', handleScroll);
  handleScroll();

  // Keep the sticky reagent bar right under the navbar, even when the navbar
  // wraps onto several lines (small screens / longer Marathi & Hindi labels).
  const navbar = document.querySelector('.navbar');
  function syncNavHeight() {
    if (navbar) {
      document.documentElement.style.setProperty('--nav-height', `${navbar.offsetHeight}px`);
    }
  }
  window.addEventListener('resize', syncNavHeight);
  document.addEventListener('adukit:languagechange', syncNavHeight);
  syncNavHeight();

  /* ------------------------------------------------------------------------
     2. VIRTUAL TEST TUBE REACTION SIMULATOR (Inside each of the 6 Reagent Cards)
     ------------------------------------------------------------------------ */
  const simButtons = document.querySelectorAll('.sim-toggle-btn');

  // Translation helper from i18n.js (falls back to plain English if missing)
  const tr = (key, fallback, vars) => {
    if (window.AduI18n) return window.AduI18n.t(key, vars);
    return fallback;
  };

  function renderSim(btn) {
    const simBox = btn.closest('.reaction-sim-box');
    const liquid = simBox.querySelector('.tube-liquid');
    const titleEl = simBox.querySelector('.sim-status-title');
    const descEl = simBox.querySelector('.sim-status-desc');
    const isTested = btn.classList.contains('tested');

    if (isTested) {
      liquid.style.backgroundColor = liquid.getAttribute('data-adult-color');
      liquid.style.height = '82%';
      titleEl.innerHTML = tr(btn.getAttribute('data-i18n-adult'), btn.getAttribute('data-adult-label'));
      descEl.innerHTML = tr('ui.simTestedDesc', 'Color change indicates adulteration! Click to reset.');
      btn.innerHTML = tr('ui.resetTube', '🔄 Reset Tube');
    } else {
      liquid.style.backgroundColor = liquid.getAttribute('data-pure-color');
      liquid.style.height = '62%';
      titleEl.innerHTML = tr(titleEl.getAttribute('data-i18n'), btn.getAttribute('data-pure-label'));
      if (btn.dataset.wasReset === 'true') {
        descEl.innerHTML = tr('ui.simResetDesc', 'Pure sample state restored.');
      }
      btn.innerHTML = tr(btn.getAttribute('data-i18n'), btn.textContent);
    }
  }

  simButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const isTested = btn.classList.toggle('tested');
      if (!isTested) btn.dataset.wasReset = 'true';
      renderSim(btn);
    });
  });

  /* ------------------------------------------------------------------------
     3. CATEGORY FILTER & HOME DETECTIVE CHECKLIST FOR DART SECTION
     ------------------------------------------------------------------------ */
  const categoryTabs = document.querySelectorAll('.cat-tab');
  const dartCards = document.querySelectorAll('.dart-card');

  categoryTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      categoryTabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');

      const selectedCategory = tab.getAttribute('data-category');

      dartCards.forEach((card) => {
        const cardCat = card.getAttribute('data-category');
        if (selectedCategory === 'all' || cardCat === selectedCategory) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  const checkButtons = document.querySelectorAll('.check-home-btn');
  const detectiveCounter = document.getElementById('detective-counter');

  function updateDetectiveCount() {
    const doneCount = document.querySelectorAll('.check-home-btn.done').length;
    if (detectiveCounter) {
      detectiveCounter.innerHTML = tr('ui.counter', `${doneCount} / ${checkButtons.length} Home Tests Completed`, {
        done: doneCount,
        total: checkButtons.length,
      });
      detectiveCounter.style.background = doneCount === checkButtons.length ? '#65B96B' : '#F28B36';
    }
  }

  checkButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const done = btn.classList.toggle('done');
      renderCheckButton(btn);
      updateDetectiveCount();
    });
  });

  function renderCheckButton(btn) {
    btn.innerHTML = btn.classList.contains('done')
      ? tr('ui.testedHome', '✅ Tested at Home!')
      : tr(btn.getAttribute('data-i18n'), '⬜ Mark Tested');
  }

  updateDetectiveCount();

  /* ------------------------------------------------------------------------
     LANGUAGE SWITCH: re-apply button states after text is translated
     ------------------------------------------------------------------------ */
  document.addEventListener('adukit:languagechange', () => {
    simButtons.forEach(renderSim);
    checkButtons.forEach(renderCheckButton);
    updateDetectiveCount();
  });

  /* ------------------------------------------------------------------------
     VIDEOS: fit each frame to the video's own shape (landscape or upright)
     so nothing gets cropped or zoomed.
     ------------------------------------------------------------------------ */
  document.querySelectorAll('.video-wrapper video').forEach((video) => {
    const fitFrame = () => {
      if (video.videoWidth && video.videoHeight) {
        video.closest('.video-wrapper').style.aspectRatio = `${video.videoWidth} / ${video.videoHeight}`;
      }
    };
    video.addEventListener('loadedmetadata', fitFrame);
    fitFrame(); // in case the video loaded before this ran
  });

  /* ------------------------------------------------------------------------
     4. REVEAL ANIMATION ON SCROLL
     ------------------------------------------------------------------------ */
  const revealElements = document.querySelectorAll('.reveal');
  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    },
    { threshold: 0.1 }
  );

  revealElements.forEach((el) => revealObserver.observe(el));
});
